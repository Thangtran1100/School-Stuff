package controllers;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.User;

@WebServlet("/PracticeQuestion")
public class PracticeQuestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public PracticeQuestion() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Random random = new Random();
		int value1 = random.nextInt(9 + 1) + 1;
		int value2 = random.nextInt(9 + 1) + 1;
		int answer = value1 + value2;
		getServletContext().setAttribute("value1", value1);
		getServletContext().setAttribute("value2", value2);
		getServletContext().setAttribute("answer", answer);
		request.getRequestDispatcher("/WEB-INF/PracticeQuestion.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int userAnswer = Integer.valueOf(request.getParameter("user_answer"));
		int id = Integer.valueOf(request.getParameter("id"));
		int answer = (int) getServletContext().getAttribute("answer");
		boolean got_answer = true;
		
		User user = null;
		
		List<User> users = (List<User>) getServletContext().getAttribute("users");

        for (User u: users) {
            if (u.getId() == id) {
            	user = u;
            	user.setAttemptedProblems(user.getAttemptedProblems() + 1);
            }   
        }
        
        if (answer != userAnswer) {
        	user.setCorrectAnswers(user.getCorrectAnswers() + 1); 
        	got_answer = false;
        }
        
        getServletContext().setAttribute("selected_user", user);
        response.sendRedirect("ViewAnswer?id=" + user.getId());
	}

}
