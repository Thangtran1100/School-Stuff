package controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import models.User;


@WebServlet("/SelectUser")
public class SelectUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public SelectUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		List<User> users = new ArrayList<User>();
		User user = new User();
		user.setName("John");
		users.add(user);
		getServletContext().setAttribute("users", users);
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/SelectUser.jsp").forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		boolean is_found = false;
		User user = null;
		
		List<User> users = (List<User>) getServletContext().getAttribute("users");

        for (User u: users) {
            if (u.getName() == name) {
            	user = u;
            	is_found = true;
            }   
        }
        
        if (!is_found) {
        	user = new User();
            users.add(user);
        }
        
        getServletContext().setAttribute("selected_user", user);
        response.sendRedirect("UserRecord?id=" + user.getId());
        
        
	}

}
