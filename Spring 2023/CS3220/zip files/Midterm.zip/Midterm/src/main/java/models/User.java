package models;


public class User {
	static int idSeed = 1;
	private String name;
	private int attemptedProblems;
	private int correctAnswers;
	private int id;
	
	
	public User() {
		id = idSeed++;
		attemptedProblems = 0;
		correctAnswers = 0;
		
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAttemptedProblems() {
		return attemptedProblems;
	}


	public void setAttemptedProblems(int attemptedProblems) {
		this.attemptedProblems = attemptedProblems;
	}


	public int getCorrectAnswers() {
		return correctAnswers;
	}


	public void setCorrectAnswers(int correctAnswers) {
		this.correctAnswers = correctAnswers;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}
	
	

}
